package Entity;

import java.util.*;

public class CavalloDondolo extends Giocattolo{
	
	//DConstructor
	public CavalloDondolo()
	{
		
	}
	
	//EConstructor
	public CavalloDondolo(String color) {
		colore=color;
	}
	
	//Private Variable
	private String colore;
	
	//Get e Set non mi servono in questo caso
}