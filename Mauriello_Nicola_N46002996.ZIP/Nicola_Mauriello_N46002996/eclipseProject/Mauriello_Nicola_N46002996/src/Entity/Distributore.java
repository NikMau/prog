package Entity;

import java.util.*;

//Implemento quello che mi serve

public class Distributore{
	
	public Distributore() {
		
	}
	
	public Distributore(int ID, String n, String c) {
		id=ID;
		nome=n;
		cognome=c;
	}
	
	private int id;
	
	private String nome;
	
	private String cognome;
}