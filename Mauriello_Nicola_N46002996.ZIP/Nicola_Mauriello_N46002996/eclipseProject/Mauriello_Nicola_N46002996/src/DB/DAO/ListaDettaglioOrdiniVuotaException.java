package DB.DAO;

public class ListaDettaglioOrdiniVuotaException extends Exception {
	
	public ListaDettaglioOrdiniVuotaException() {
		super("\nNessun  dettaglio ordine presente nel sistema!.\n");
	}

}